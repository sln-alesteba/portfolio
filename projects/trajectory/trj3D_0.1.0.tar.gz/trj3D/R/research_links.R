# https://cran.r-project.org/web/packages/trajr/vignettes/simulations.html

# rediscretize -> importante ->
# necesitaría saber iterar por ella: # algoritmos que ya tienes:
# puedo hacerlo de alguna forma sencilla ?
# interesante el concept de la rediscretización del tiempo:
# si es necesario puedo hacerlo :
# difference between rediscretize and resample:

# otro recurso importante:

# https://traja.readthedocs.io/en/latest/periodicity.html

# este tipo de datos ya más de análisis pueden dar lugar a ser alamacenados en BD.
# puedo realizar varias técnicas de clustering y demás:

# enlace al proyecto : fijarse en la gente que lo mueve:

# https://github.com/traja-team

# importante para conectar python con R:

# https://rstudio.github.io/reticulate/?_gl=1*11tx7cw*_ga*MjA2NDA5NzU0Mi4xNzAyNDY5NjU3*_ga_2C0WZ1JHG0*MTcwMjQ2OTY1Ny4xLjAuMTcwMjQ2OTY1Ny4wLjAuMA..

# puedo diseñar el paquete en python e implementar las GANs para decir algo sobre el forecasting y trayectories:

# https://traja.readthedocs.io/en/latest/_modules/traja/trajectory.html
