
# stepLengths <- function(trj, startIndex = 2, endIndex = length(trj)) {
#
#   return  ( sum(trj$displacement[startIndex:endIndex]) )
#
# }

# need different implementation based on euler;


stepLengths <- function(trj, startIndex = 2, endIndex = length(trj$x)) {

  sum = 0

  for (t in startIndex:endIndex) {

    pt1 <- c(x = trj$x[t],  y = trj$y[t], z = trj$z[t] )

    pt2 <- c(x = trj$x[t-1], y = trj$y[t-1], z = trj$z[t-1])

    sum <- sum + euc.dist (pt1 , pt2)
  }

  return(sum)

}

# Substitute for the R base function `Arg(z)` that treats the argument of zero
# as undefined. The base R function returns 0.

# distance <- function(trj, startIndex = 1, endIndex = nrow(trj)) {
#
#   pt1 <- c(x = trj$x[startIndex],   y = trj$y[startIndex])
#
#   pt2 <- c(x = trj$x[endIndex],  y = trj$y[endIndex])
#
#   return( euc.dist (pt1 , pt2) )
# }

straightness <- function(trj) {

  return( length(trj) / stepLengths(trj) )
}




